/* Florida Gulf Coast Guide: new website DRAFT config.
   SIGNUP_ENDPOINT points at the already-deployed Apps Script relay /exec URL.
   The live project is still running relay v1 until Code.gs is replaced with
   apps_script_Code_v2.gs and a new version is published on the same deployment.
   Forms post text/plain JSON; signup.js treats {ok:false} as a failure.
   GUIDE_PDF_URL is the approved v7_23w PDF, hosted on this site under a stable name. */
window.FGCG_CONFIG = {
  SIGNUP_ENDPOINT: "https://script.google.com/macros/s/AKfycbyvj0Xg7Ety0TlSJLQVtYfcap7jXDispDF4tu12aa1XGptN2_M6SOEr69-T_eZGyiSQkg/exec",
  GUIDE_PDF_URL: "https://floridagulfcoastguide.com/florida-gulf-coast-guide.pdf"
};
