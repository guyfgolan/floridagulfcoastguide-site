/* Menu toggle + background video controls (hero and areas). No libraries. */
(function(){
  var d=document; d.documentElement.classList.add('js');
  var t=d.querySelector('.nav-toggle'), n=d.getElementById('site-nav');
  if(t&&n){t.addEventListener('click',function(){var o=t.getAttribute('aria-expanded')==='true';t.setAttribute('aria-expanded',String(!o));n.classList.toggle('open',!o);});n.addEventListener('click',function(e){if(e.target.closest&&e.target.closest('a[href^="#"]')){t.setAttribute('aria-expanded','false');n.classList.remove('open');}});}
  // Pause button shows only in Guy's local preview (file://) or with ?preview in the URL; visitors get a constant loop with no controls.
  var dev=location.protocol==='file:'||/[?&]preview\b/.test(location.search);
  var reduce=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  Array.prototype.forEach.call(d.querySelectorAll('.hero-video, .bg-video'),function(v){
    var b=v.parentNode.querySelector('.video-toggle');
    function setBtn(playing){ if(!b) return; b.setAttribute('aria-pressed',String(!playing)); b.setAttribute('aria-label',playing?'Pause background video':'Play background video'); b.classList.toggle('paused',!playing); }
    if(reduce){ v.removeAttribute('autoplay'); try{v.pause();}catch(e){} v.hidden=true; if(b) b.hidden=true; return; }
    // If no video file loads, keep the poster photo and hide the button.
    var srcs=v.querySelectorAll('source'), last=srcs[srcs.length-1];
    function noVideo(){ v.hidden=true; if(b) b.hidden=true; }
    if(last) last.addEventListener('error',noVideo); v.addEventListener('error',noVideo);
    if(!dev && b){ b.remove(); b=null; }
    v.addEventListener('playing',function(){ if(b){b.hidden=false;} setBtn(true); });
    if(b){ b.addEventListener('click',function(){ if(v.paused){v.play();setBtn(true);} else {v.pause();setBtn(false);} }); }
    // Videos marked data-autoplay start only after the page has painted (poster photo is the first paint),
    // and below-the-fold ones wait until they're near the screen. Saves megabytes on first load.
    if(v.hasAttribute('data-autoplay')){
      var go=function(){ v.preload='auto'; var p=v.play(); if(p&&p.catch) p.catch(function(){}); };
      var start=function(){
        if('IntersectionObserver' in window){
          var io=new IntersectionObserver(function(es){ es.forEach(function(e){ if(e.isIntersecting){ io.disconnect(); go(); } }); },{rootMargin:'200px 0px'});
          io.observe(v);
        } else { go(); }
      };
      if(d.readyState==='complete') setTimeout(start,0); else window.addEventListener('load',function(){ setTimeout(start,0); });
    }
  });
})();
