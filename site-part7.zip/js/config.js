/* Florida Gulf Coast Guide: new website DRAFT config.
   SIGNUP_ENDPOINT is empty on purpose, so the forms validate but send nothing while Guy reviews.
   To go live (only with Guy's OK), paste the BoldTrail relay URL used by the live guide page
   (see /workspace/fgcg_site/js/config.js and BOLDTRAIL_SIGNUP.md). */
window.FGCG_CONFIG = { SIGNUP_ENDPOINT: "" };
