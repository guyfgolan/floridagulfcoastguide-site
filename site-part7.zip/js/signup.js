/* Guide signup form. No libraries. Sends one text/plain JSON POST to SIGNUP_ENDPOINT
   (text/plain avoids a CORS preflight, which Apps Script can't answer). */
(function () {
  var cfg = window.FGCG_CONFIG || {};
  var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  var forms = document.querySelectorAll('form[data-signup]');
  Array.prototype.forEach.call(forms, function (form) {
    var started = Date.now();
    var input = form.querySelector('input[type=email]');
    var btn = form.querySelector('button[type=submit]');
    var msg = form.querySelector('.msg');
    var hp = form.querySelector('input[name=company]');
    function say(text, cls) { msg.textContent = text; msg.className = 'msg ' + (cls || ''); }
    input.addEventListener('input', function () {
      input.removeAttribute('aria-invalid'); if (msg.classList.contains('err')) say('');
    });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var email = (input.value || '').trim();
      if (!EMAIL_RE.test(email) || email.length > 254) {
        input.setAttribute('aria-invalid', 'true');
        say('Please enter a valid email, like name@example.com.', 'err');
        input.focus();
        return;
      }
      // Honeypot filled: likely a bot. Send nothing and show nothing (never the success copy).
      if (hp && hp.value) { say(''); return; }
      var endpoint = (cfg.SIGNUP_ENDPOINT || '').trim();
      if (!endpoint) {
        say('Thanks! This form is in preview mode right now, so nothing was sent.', 'ok');
        return;
      }
      // Submitted too fast: send nothing, show a neutral note (never the success copy).
      if (Date.now() - started < 1500) { say('Please try again in a moment.'); return; }
      btn.disabled = true; var label = btn.textContent; btn.textContent = 'Sending...';
      fetch(endpoint, {
        method: 'POST',
        redirect: 'follow',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify({ email: email, company: hp ? hp.value : '', page: location.pathname, form: form.getAttribute('data-signup'), elapsed_ms: Date.now() - started })
      }).then(function (r) { return r.json(); })
        .then(function (res) {
          if (res && res.ok) { done(); }
          else { throw new Error((res && res.error) || 'failed'); }
        })
        .catch(function () {
          btn.disabled = false; btn.textContent = label;
          say('Sorry, that did not go through. Please try again, or email guy@floridagulfcoastguide.com.', 'err');
        });
    });
    // Only called after a real endpoint has accepted the email (res.ok).
    function done() {
      form.querySelector('.row').hidden = true;
      say('You\u2019re signed up! Watch your inbox for the free Florida Gulf Coast Guide.', 'ok');
      msg.setAttribute('tabindex', '-1'); msg.focus();
    }
  });
})();
