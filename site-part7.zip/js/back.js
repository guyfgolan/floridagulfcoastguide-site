/* Back control: go back in history when the visitor came from this site; otherwise follow the link's href (the parent page). */
(function(){
  var a=document.querySelector('a.back-link');
  if(!a)return;
  a.addEventListener('click',function(e){
    var r=document.referrer,ok=false;
    try{
      if(r&&history.length>1){
        var u=new URL(r);
        ok=(location.protocol==='file:')?(u.protocol==='file:'):(u.origin===location.origin);
      }
    }catch(err){ok=false}
    if(ok){e.preventDefault();history.back();}
  });
})();
