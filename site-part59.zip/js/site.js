/* Menu toggle + background video controls (hero and areas). No libraries. */
(function(){
  var d=document; d.documentElement.classList.add('js');
  var t=d.querySelector('.nav-toggle'), n=d.getElementById('site-nav');
  if(t&&n){t.addEventListener('click',function(){var o=t.getAttribute('aria-expanded')==='true';t.setAttribute('aria-expanded',String(!o));n.classList.toggle('open',!o);});n.addEventListener('click',function(e){if(e.target.closest&&e.target.closest('a[href^="#"]')){t.setAttribute('aria-expanded','false');n.classList.remove('open');}});}

  // Pause button shows only in Guy's local preview (file://) or with ?preview in the URL; visitors get a constant loop with no controls.
  var dev=location.protocol==='file:'||/[?&]preview\b/.test(location.search);
  var reduceMQ=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)');
  var reduce=!!(reduceMQ&&reduceMQ.matches);

  function inView(el){
    var r=el.getBoundingClientRect();
    var vh=window.innerHeight||d.documentElement.clientHeight;
    return r.bottom>=-200 && r.top<=vh+200;
  }

  Array.prototype.forEach.call(d.querySelectorAll('.hero-video, .bg-video'),function(v){
    var b=v.parentNode.querySelector('.video-toggle');
    var userPaused=false;
    var wantPlay=false;
    var retryTimer=0;
    function setBtn(playing){ if(!b) return; b.setAttribute('aria-pressed',String(!playing)); b.setAttribute('aria-label',playing?'Pause background video':'Play background video'); b.classList.toggle('paused',!playing); }
    function canAuto(){ return !reduce && !userPaused && !v.hidden && !d.hidden && inView(v); }
    function tryPlay(){
      if(!canAuto()) return;
      wantPlay=true;
      v.loop=true;
      v.muted=true;
      v.preload='auto';
      var p=v.play();
      if(p&&p.catch) p.catch(function(){
        if(!wantPlay) return;
        clearTimeout(retryTimer);
        retryTimer=setTimeout(tryPlay, 400);
      });
    }
    if(reduce){ v.removeAttribute('autoplay'); try{v.pause();}catch(e){} v.hidden=true; if(b) b.hidden=true; return; }

    // If no video file loads, keep the poster photo and hide the button.
    var srcs=v.querySelectorAll('source'), last=srcs[srcs.length-1];
    function noVideo(){ v.hidden=true; if(b) b.hidden=true; }
    if(last) last.addEventListener('error',noVideo); v.addEventListener('error',noVideo);
    if(!dev && b){ b.remove(); b=null; }
    v.addEventListener('playing',function(){ if(b){b.hidden=false;} setBtn(true); });
    if(b){ b.addEventListener('click',function(){
      if(v.paused){ userPaused=false; tryPlay(); setBtn(true); }
      else { userPaused=true; wantPlay=false; v.pause(); setBtn(false); }
    }); }

    // Autoplay videos start as soon as they are near the screen, keep playing across
    // loops, tab switches and scroll-back, and do not fight a visitor who paused them
    // or asked for reduced motion.
    if(v.hasAttribute('data-autoplay')){
      if('IntersectionObserver' in window){
        var io=new IntersectionObserver(function(es){
          es.forEach(function(e){
            if(e.isIntersecting) tryPlay();
            else if(!userPaused){ wantPlay=false; try{v.pause();}catch(err){} }
          });
        },{rootMargin:'200px 0px'});
        io.observe(v);
      }
      tryPlay();
      if(d.readyState!=='complete') window.addEventListener('load',function(){ setTimeout(tryPlay,0); });
      v.addEventListener('ended',function(){
        if(!canAuto()) return;
        try{v.currentTime=0;}catch(e){}
        tryPlay();
      });
      function recover(){ if(canAuto() && (v.paused || v.ended || v.readyState<2)) tryPlay(); }
      v.addEventListener('stalled',recover);
      v.addEventListener('waiting',recover);
      v.addEventListener('suspend',recover);
      v.addEventListener('pause',function(){ if(canAuto()) tryPlay(); });
      d.addEventListener('visibilitychange',function(){ if(!d.hidden) tryPlay(); });
      window.addEventListener('pageshow',function(){ tryPlay(); });
    }
  });

  // Homepage logo entrance: fade in, then out, once per page load. Removed afterwards
  // so it never repeats when the hero video loops.
  (function(){
    var hero=d.querySelector('.hero');
    var overlay=d.querySelector('.hero-enter');
    if(!hero||!overlay) return;
    if(reduce){
      if(overlay.parentNode) overlay.parentNode.removeChild(overlay);
      return;
    }
    var finished=false;
    function finish(){
      if(finished) return;
      finished=true;
      if(overlay.parentNode) overlay.parentNode.removeChild(overlay);
      hero.classList.remove('is-entering');
      hero.classList.add('is-entered');
    }
    hero.classList.add('is-entering');
    requestAnimationFrame(function(){ requestAnimationFrame(function(){ overlay.classList.add('is-in'); }); });
    var fadeIn=900, hold=800, fadeOut=900;
    setTimeout(function(){
      overlay.classList.remove('is-in');
      overlay.classList.add('is-out');
      overlay.addEventListener('transitionend',finish);
      setTimeout(finish, fadeOut+120);
    }, fadeIn+hold);
  })();
})();
